package com.mycompany.datosempresas;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import org.jfree.chart.ChartFactory; 
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;

public class empresascvs {
    public static void main(String[] args) {
        String archivo = "1000_empresas_grandes.csv";

        try {
            BufferedReader lector = new BufferedReader(new FileReader(archivo));
            String linea;

            DefaultCategoryDataset dataset = new DefaultCategoryDataset();

            // Leer línea por línea del archivo de texto
            int n = 1000;
            while ((linea = lector.readLine()) != null && --n > 0) {
                String[] datos = linea.split(","); // Separar los datos de la línea

                String razonSocial = datos[2]; // RAZON SOCIAL
                double ingresosOperacionales = Double.parseDouble(datos[10]); // INGRESOS OPERACIONALES

                dataset.addValue(ingresosOperacionales, "Ingresos Operacionales", razonSocial);
            }

            // Crear el gráfico de barras
            JFreeChart chart = ChartFactory.createBarChart("Ingresos Operacionales", "Razón Social", "Ingresos", dataset);

            // Guardar el gráfico como una imagen
            ChartUtilities.saveChartAsPNG(new File("grafico.png"), chart, 800, 600);

            // Cerrar el lector
            lector.close();
        } catch (IOException e) {
            System.out.println("Error al leer el archivo: " + e.getMessage());
        }
    }
}
