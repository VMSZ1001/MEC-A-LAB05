
import com.lowagie.text.Document;
import com.lowagie.text.DocumentException;
import com.lowagie.text.PageSize;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.text.DecimalFormat;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PiePlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.category.DefaultCategoryDataset;


public class Graf_NivelEst_x_Tipo extends JFrame{

    JButton jbPDF; //crear PDF por grafica
    JLabel jlMensaje; //mostrar mensaje de error
    
    JFreeChart chart;
    int contadores[][] = new int[5][2];
    //contadores[0][0] conteo de cantidad de Tecnologos catedraticos
    //contadores[0][1] conteo de cantidad de Tecnologos tiempo completo
    
    //contadores[1][0] conteo de cantidad de Profesionales catedraticos
    //contadores[1][1] conteo de cantidad de Profesionales tiempo completo
    
    //contadores[2][0] conteo de cantidad de Especialistas catedraticos
    //contadores[2][1] conteo de cantidad de Especialistas tiempo completo
    
    // .....
    
    public Graf_NivelEst_x_Tipo() {
        // crear el JFame
        super("Grafico - Nivel de estudios x Tipo contrato (Facultad de Ingenieria)");
        setSize(800, 580);
        setLayout(null);
        setResizable(false);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        crearGUI();
        crearGrafico();
        
        setVisible(true);
    }
    
    public void crearGUI(){
        jlMensaje = new JLabel(""); 
        jlMensaje.setBounds(1, 300, 800, 30);
        jlMensaje.setFont(new Font("Tahoma", Font.BOLD, 20));
        jlMensaje.setHorizontalAlignment(SwingConstants.CENTER);
        add(jlMensaje);
        
        ImageIcon img = new ImageIcon(getClass().getResource("imagenes/pdf-icon.png"));
        jbPDF = new JButton("Crear PDF con la gráfica", img);
        jbPDF.setBounds(540, 480, 230, 50);
        jbPDF.setCursor(new Cursor(Cursor.HAND_CURSOR));
        jbPDF.setBorderPainted(false);
        jbPDF.setContentAreaFilled(false);
        jbPDF.setFocusPainted(false);        
        jbPDF.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                evento_jbPDF();
            }
        });
        jbPDF.setVisible(false);
        add(jbPDF);
    }
    
    public void crearGrafico() {        
        if(!cant_X_nivelEstudios("docentes.csv")){//si no hay error al leer el archivo....            
            //asignar los datos en el dataset
            DefaultCategoryDataset dataset = new DefaultCategoryDataset();

            dataset.addValue(contadores[0][0], "Catedratico", "Tecnólogo");
            dataset.addValue(contadores[0][1], "Tiempo completo", "Tecnólogo");
            
            dataset.addValue(contadores[1][0], "Catedratico", "Profesional");
            dataset.addValue(contadores[1][1], "Tiempo completo", "Profesional");
            
            dataset.addValue(contadores[2][0], "Catedratico", "Especialización");
            dataset.addValue(contadores[2][1], "Tiempo completo", "Especialización");
            
            dataset.addValue(contadores[3][0], "Catedratico", "Maestria");
            dataset.addValue(contadores[3][1], "Tiempo completo", "Maestria");
            
            dataset.addValue(contadores[4][0], "Catedratico", "Doctorado");
            dataset.addValue(contadores[4][1], "Tiempo completo", "Doctorado");
            
            // crear el grafico
            chart = ChartFactory.createBarChart3D(
                    "Nivel de estudios x Tipo contrato", // chart title
                    "Nivel de estudios", // etiqueta del eje X
                    "Cantidad", // etiqueta del eje Y
                    dataset, // data
                    PlotOrientation.VERTICAL, //Orientacion HORIZONTAL o VERTICAL
                    true, 
                    true,
                    false
            );
            
            //subtitulo del grafico  
            TextTitle subtitle1 = new TextTitle("Facultad de Ingenieria ");
            chart.addSubtitle(subtitle1);
                        
            // adicionar el chart al panel
            ChartPanel panel = new ChartPanel(chart, false);
            panel.setBounds(10, 20, 760, 450);
            add(panel);
            
            jbPDF.setVisible(true);// hacer visible el boton para crear el PDF
        }
    }
    
    public boolean cant_X_nivelEstudios(String fileName) {
        FileReader fr = null; //declaracion de un objeto de la clase FileReader
        boolean error = false; //variable para determinar si existio error al tratar de abrir el archivo

        try {// tratar la excepcion que puede lanzar el constructor
            fr = new FileReader(fileName);// instanciar el objeto
        } catch (IOException e) {// atrapar la excepcion que puede lanzar el constructor
            error = true;// existio un error al tratar de abrir el archivo
            JOptionPane.showMessageDialog(this, 
                    "Error al tratar de abrir el archivo '" + fileName + "'");
        }

        if (!error) {// sino hubo error al tratar de abrir el archivo, entonces leerlo
            // crear un objeto de BufferedReader y enviarle el objeto FileReader
            BufferedReader br = new BufferedReader(fr);
            String linea = "";// almacenar toda una linea del documento 
            String tokens[];

            try {// tratar la excepcion que puede lanzar el metodo readLine().
                // leer cada linea del docuemento y almacenarla en en String.
                // el bucle se repite mientras no se llegue al fin del documento
                while ((linea = br.readLine()) != null) {
                    //System.out.println(registro);// imprimir la linea leida
                    tokens = linea.split(";");
                    //tokens[] = {"10", "1", "Especializacion"}
                    //posicion      0    1           2
                    if(tokens[1].equals("1")){ // evaluar la posicion 1 del array tokens, donde esta el nivel de estudios
                                                //1 == catedratico
                        switch(tokens[2]){ //evaluar la posicion 2 del array tokens, donde esta el nivel de estudios
                            case "Tecnologo":       contadores[0][0]++; break;
                            case "Profesional":     contadores[1][0]++; break;
                            case "Especializacion": contadores[2][0]++; break;
                            case "Maestria":        contadores[3][0]++; break;
                            case "Doctorado":       contadores[4][0]++; break;
                        }
                    }else{// 2 == Tiempo completo                                                
                        switch(tokens[2]){// evaluar la posicion 2 del array tokens, donde esta el nivel de estudios
                            case "Tecnologo":       contadores[0][1]++; break;
                            case "Profesional":     contadores[1][1]++; break;
                            case "Especializacion": contadores[2][1]++; break;
                            case "Maestria":        contadores[3][1]++; break;
                            case "Doctorado":       contadores[4][1]++; break;
                        }
                    }
                }
            } catch (IOException e) {// atrapar la excepcion que puede lanzar el metodo readLine()
                JOptionPane.showMessageDialog(this, 
                    "Error al tratar de leer el archivo '" + fileName + "'");
            }

            try {// tratar la excepcion que puede lanzar el metodo close()
                fr.close();
            } catch (IOException e) {// atrapar la excepcion que puede lanzar el metodo close()
                JOptionPane.showMessageDialog(this, 
                    "Error al tratar de cerrar el archivo '" + fileName + "'");
            }
        }
        
        return error;
    }
    
    private void evento_jbPDF() {
        try {//Crear grafico como una imagen  
            ChartUtilities.saveChartAsPNG(
            //ChartUtilities.saveChartAsJPEG(
                    //damos la ubicacion donde se guardara la imagen, y su extension
                    new File("Grafico-Nivel estudios_x_Tipo_contrato (Fac Ing).png"), //la ruta y el nombre de la imagen a crear
                    chart, //la grafica
                    760,//ancho 
                    450);//alto
            
            crearPDF();

        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error creando grafico.");
        }
    }
    
    public void crearPDF() {
        // step 1: creation of a document-object        
        Document document = new Document();

        try {
            // step 2: creation of the writer
            PdfWriter writer = PdfWriter.getInstance(document, 
                    new FileOutputStream("Grafico-Nivel estudios_x_Tipo_contrato (Fac Ing).pdf"));

            // step 3: we open the document
            document.open();
            
            // step 4: we grab the ContentByte and do some stuff with it
            PdfContentByte cb = writer.getDirectContent();
            Graphics g = cb.createGraphicsShapes(PageSize.LETTER.getWidth(), PageSize.LETTER.getHeight());
                        
            Font font1 = new Font("Tahoma", Font.BOLD, 25);
            g.setFont(font1);

            g.setColor(Color.RED);
            g.drawString("Informe de Docentes", 165, 30);
                                    
            ImageIcon img1 = new ImageIcon("Grafico-Nivel estudios_x_Tipo_contrato (Fac Ing).png");
            g.drawImage(img1.getImage(), 40, 60, 520, 320, null);
            
        } catch (DocumentException de) {
            System.err.println(de.getMessage());
        } catch (FileNotFoundException ex) {
            System.err.println(ex.getMessage());
        }

        // step 5: we close the document
        document.close();

        pregunta();
    }
    
    private void pregunta() {
        int res = JOptionPane.showConfirmDialog(this, 
            "Se creo el archivo 'Grafico-Nivel estudios_x_Tipo_contrato (Fac Ing).pdf' en la carpeta del proyecto.\n\n¿Desea ver el archivo?",
            "Confirmación",
            JOptionPane.YES_NO_OPTION);
        
        if(res == JOptionPane.YES_OPTION){
            File fl = new File("Grafico-Nivel estudios_x_Tipo_contrato (Fac Ing).pdf");// cargar el documento PDF
            try {
                Desktop.getDesktop().open(fl);// abrir el documento con el programa por defecto para el tipo archivo PDF
            } catch (IOException e) {
                JOptionPane.showMessageDialog(this,
                    "Error al tratar de abrir el archivo 'Grafico-Nivel estudios_x_Tipo_contrato (Fac Ing).pdf'");
            }
        }
    }
    
    /*
    public static void main(String[] args) {
        Graf_NivelEst_x_Tipo demo = new Graf_NivelEst_x_Tipo();
    }
    */
}
