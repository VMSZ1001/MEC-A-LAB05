
package com.mycompany.datosempresas;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

public class empresascvs extends JFrame {
    private Map<String, List<String>> filtros;
    private JTable table;
    private final JButton btnGenerarReporte;
    private final JComboBox<String> comboBoxTipoGrafica;
    private final JCheckBox checkBoxTop3;
    private DefaultCategoryDataset barDataset;
    private DefaultPieDataset pieDataset;

    public empresascvs() {
        super("Aplicación de Empresas");

        filtros = new HashMap<>();

        // Configurar la interfaz de usuario
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);

        // Panel de filtros
        JPanel panelFiltros = new JPanel();
        panelFiltros.add(new JLabel("Filtros:"));

        // Leer el archivo fuente y obtener los valores únicos para cada filtro
        try {
            try (BufferedReader lector = new BufferedReader(new FileReader("empresas_grandes.csv"))) {
                String linea = lector.readLine();
                if (linea != null) {
                    String[] headers = linea.split(",");
                    int numColumnas = headers.length;
                    
                    // Crear y agregar los filtros
                    for (int i = 0; i < numColumnas; i++) {
                        String columna = headers[i];
                        List<String> valoresUnicos = new ArrayList<>();
                        
                        while ((linea = lector.readLine()) != null) {
                            String[] datos = linea.split(",");
                            if (datos.length > i) {
                                String valor = datos[i].trim();
                                if (!valoresUnicos.contains(valor)) {
                                    valoresUnicos.add(valor);
                                }
                            }
                        }
                        
                        filtros.put(columna, valoresUnicos);
                    }
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al leer el archivo: " + e.getMessage());
            System.exit(1);
        }

        // Agregar los filtros como componentes en el panel
        for (Map.Entry<String, List<String>> entry : filtros.entrySet()) {
            String columna = entry.getKey();
            List<String> valoresUnicos = entry.getValue();

            panelFiltros.add(new JLabel(columna + ":"));
            JComboBox<String> comboBoxFiltro = new JComboBox<>(valoresUnicos.toArray(new String[0]));
            panelFiltros.add(comboBoxFiltro);
        }

        // Panel de gráficas
        JPanel panelGraficas = new JPanel();
        panelGraficas.add(new JLabel("Tipo de Gráfica:"));
        comboBoxTipoGrafica = new JComboBox<>(new String[] { "Barra", "Torta" });
        panelGraficas.add(comboBoxTipoGrafica);
        checkBoxTop3 = new JCheckBox("Mostrar Top 3");

        // Botón generar reporte
        btnGenerarReporte = new JButton("Generar Reporte");
            // Agregar listeners
    btnGenerarReporte.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            generarReporte();
        }
    });

    // Configurar el layout principal
    setLayout(new BorderLayout());
    add(panelFiltros, BorderLayout.NORTH);
    add(new JScrollPane(table), BorderLayout.CENTER);
    add(panelGraficas, BorderLayout.SOUTH);
    add(btnGenerarReporte, BorderLayout.SOUTH);

    // Mostrar la ventana principal
    setVisible(true);
}

private void generarReporte() {
    // Obtener los filtros seleccionados
    Map<String, String> filtrosSeleccionados = new HashMap<>();
    for (Map.Entry<String, List<String>> entry : filtros.entrySet()) {
        String columna = entry.getKey();
        JComboBox<String> comboBoxFiltro = (JComboBox<String>) getContentPane().getComponent(1 + filtros.size() * 2 + 1 + 1 + 1);
        String valorFiltro = (String) comboBoxFiltro.getSelectedItem();
        filtrosSeleccionados.put(columna, valorFiltro);
    }

    // Filtrar los datos según los filtros seleccionados
    List<String[]> datosFiltrados = new ArrayList<>();
    try {
        BufferedReader lector = new BufferedReader(new FileReader("empresas_grandes.csv"));
        String linea;
        while ((linea = lector.readLine()) != null) {
            String[] datos = linea.split(",");
            boolean pasaFiltros = true;
            for (Map.Entry<String, String> entry : filtrosSeleccionados.entrySet()) {
                String columna = entry.getKey();
                String valorFiltro = entry.getValue();
                int indiceColumna = getColumnIndex(columna);

                if (indiceColumna != -1 && !datos[indiceColumna].equals(valorFiltro)) {
                    pasaFiltros = false;
                    break;
                }
            }
            if (pasaFiltros) {
                datosFiltrados.add(datos);
            }
        }
        lector.close();
    } catch (IOException e) {
        JOptionPane.showMessageDialog(this, "Error al leer el archivo: " + e.getMessage());
        return;
    }

    // Mostrar los resultados principales (Top 3 empresas más grandes)
    if (checkBoxTop3.isSelected()) {
        mostrarTop3Empresas(datosFiltrados);
    }

    // Generar gráficas
    if (comboBoxTipoGrafica.getSelectedItem().equals("Barra")) {
        generarGraficaBarra(datosFiltrados);
    } else if (comboBoxTipoGrafica.getSelectedItem().equals("Torta")) {
        generarGraficaTorta(datosFiltrados);
    }

    // Guardar el reporte en un archivo CSV
    guardarReporteCSV(datosFiltrados);
}

private void mostrarTop3Empresas(List<String[]> datosFiltrados) {
    // Ordenar los datos por el criterio deseado (en este caso, por ingresos operacionales de mayor a menor)
    datosFiltrados.sort((d1, d2) -> {
        double ingresos1 = Double.parseDouble(d1[10]);
        double ingresos2 = Double.parseDouble(d2[10]);
        return Double.compare(ingresos2, ingresos1);
    });

    // Mostrar las tres primeras empresas
    System.out.println("Top 3 empresas más grandes:");
    for (int i = 0; i < 3 && i < datosFiltrados.size(); i++) {
        String[] datos = datosFiltrados.get(i);
        String razonSocial = datos[2];
        double ingresosOperacionales = Double.parseDouble(datos[10]);
    System.out.println((i + 1) + ". " + razonSocial + " - Ingresos Operacionales: " + ingresosOperacionales);
    }
    }

    private void generarGraficaBarra(List<String[]> datosFiltrados) {
    // Crear el dataset para la gráfica de barra
    barDataset = new DefaultCategoryDataset();
    for (String[] datos : datosFiltrados) {
    String razonSocial = datos[2];
    double ingresosOperacionales = Double.parseDouble(datos[10]);
    barDataset.setValue(ingresosOperacionales, "Ingresos Operacionales", razonSocial);
    }
        // Crear la gráfica de barra
    JFreeChart chart = ChartFactory.createBarChart("Ingresos Operacionales por Empresa", "Empresa", "Ingresos Operacionales",
        barDataset);

    // Guardar la gráfica en un archivo de imagen
    try {
    ChartUtilities.saveChartAsPNG(new File("grafica_barra.png"), chart, 800, 600);
    } catch (IOException e) {
    JOptionPane.showMessageDialog(this, "Error al guardar la gráfica de barra: " + e.getMessage());
    }
  }

private void generarGraficaTorta(List<String[]> datosFiltrados) {
    // Crear el dataset para la gráfica de torta
   pieDataset = new DefaultPieDataset();
     for (String[] datos : datosFiltrados) {
    String razonSocial = datos[2];
    double ingresosOperacionales = Double.parseDouble(datos[10]);
    pieDataset.setValue(razonSocial, ingresosOperacionales);
    }
     // Crear la gráfica de torta
    JFreeChart chart = ChartFactory.createPieChart("Ingresos Operacionales por Empresa", pieDataset);

    // Guardar la gráfica en un archivo de imagen
    try {
    ChartUtilities.saveChartAsPNG(new File("grafica_torta.png"), chart, 800, 600);
    } catch (IOException e) {
    JOptionPane.showMessageDialog(this, "Error al guardar la gráfica de torta: " + e.getMessage());
  }
    }

private void guardarReporteCSV(List<String[]> datosFiltrados) {
    try {
    FileWriter escritor = new FileWriter("reporte.csv");
    for (String[] datos : datosFiltrados) {
    for (String dato : datos) {
    escritor.append(dato);
    escritor.append(",");
 }
    escritor.append("\n");
 }
    escritor.close();
    JOptionPane.showMessageDialog(this, "El reporte se ha guardado exitosamente en el archivo reporte.csv");
} catch (IOException e) {
    JOptionPane.showMessageDialog(this, "Error al guardar el reporte: " + e.getMessage());
    }
}

private int getColumnIndex(String columna) {
    Component[] headers = table.getTableHeader().getComponents();
    for (int i = 0; i < headers.length; i++) {
    if (headers[i].equals(columna)) {
    return i;
    }
}
    return -1;
}

public static void main(String[] args) {
    new empresascvs();
    }
  }
